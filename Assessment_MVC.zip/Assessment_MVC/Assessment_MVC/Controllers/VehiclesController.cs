﻿using Assessment_MVC.Data;
using Assessment_MVC.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Assessment_MVC.Controllers
{
        [Route("api/[controller]")]
        [ApiController]
        public class VehiclesController : ControllerBase
        {
            private readonly DataContext _context;

            public VehiclesController(DataContext context)
            {
                _context = context;
            }

            [HttpGet]
            public async Task<ActionResult<List<Controllers.VehiclesController>>> Get()
            {
                return Ok(await _context.Vehicles.ToListAsync());
            }

            [HttpPost]

            public async Task<ActionResult<List<Controllers.VehiclesController>>> AddVehicle(Controllers.VehiclesController vehicle)
            {
                _context.Vehicles.Add(vehicle);
                await _context.SaveChangesAsync();
                return Ok(await _context.Vehicles.ToListAsync());
            }

            [HttpPut]
            public async Task<ActionResult<List<Controllers.VehiclesController>>> UpdateVehicle(Vehicle request)
            {
                var dbvehicle = new Vehicle();
                if (dbvehicle == null)
                    return BadRequest("Hero not found");

                dbvehicle.Brand = request.Brand;
                dbvehicle.Vin = request.Vin;
                dbvehicle.Color = request.Color;
                dbvehicle.Year = request.Year;
                dbvehicle.Owner_Id = request.Owner_Id;

                await _context.SaveChangesAsync();

                return Ok(await _context.Vehicles.ToListAsync());
            }
        }
    }

