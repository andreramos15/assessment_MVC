﻿using Assessment_MVC.Data;
using Assessment_MVC.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Assessment_MVC.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClaimsController : ControllerBase
    {

        private readonly DataContext _context;

            public ClaimsController(DataContext context)
            {
                _context = context;
            }

            [HttpGet]
            public async Task<ActionResult<List<Controllers.ClaimsController>>> Get()
            {
                return Ok(await _context.Claims.ToListAsync());
            }

            [HttpPost]

            public async Task<ActionResult<List<ClaimsController>>> AddClaim(ClaimsController claim)
            {
                _context.Claims.Add(claim);
                await _context.SaveChangesAsync();
                return Ok(await _context.Claims.ToListAsync());
            }

            [HttpPut]
            public async Task<ActionResult<List<ClaimsController>>> UpdateClaim(Claim request)
            {
            var dbclaim = new Claim();
                if (dbclaim == null)
                    return BadRequest("Hero not found");

                dbclaim.Description = request.Description;
                dbclaim.Status = request.Status;
                dbclaim.Date = request.Date;
                dbclaim.Vehicle_Id = request.Vehicle_Id;

                await _context.SaveChangesAsync();

                return Ok(await _context.Claims.ToListAsync());
            }
        }
    }

