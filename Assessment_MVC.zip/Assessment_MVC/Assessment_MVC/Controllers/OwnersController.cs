﻿using Assessment_MVC.Data;
using Assessment_MVC.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Assessment_MVC.Controllers
{
        [Route("api/[controller]")]
        [ApiController]
        public class OwnersController : ControllerBase
        {
            private readonly DataContext _context;

            public OwnersController(DataContext context)
            {
                _context = context;
            }

            [HttpGet]
            public async Task<ActionResult<List<Controllers.OwnersController>>> Get()
            {
                return Ok(await _context.Owners.ToListAsync());
            }

            [HttpPost]

            public async Task<ActionResult<List<Controllers.OwnersController>>> AddOwner(Controllers.OwnersController owner)
            {
                _context.Owners.Add(owner);
                await _context.SaveChangesAsync();
                return Ok(await _context.Owners.ToListAsync());
            }

            [HttpPut]
            public async Task<ActionResult<List<Controllers.OwnersController>>> UpdateOwner(Owner request)
            {
                var dbowners = new Owner(); ;
                if (dbowners == null)
                    return BadRequest("Hero not found");

                dbowners.FirstName = request.FirstName;
                dbowners.LastName = request.LastName;
                dbowners.DriverLicense = request.DriverLicense;

                await _context.SaveChangesAsync();

                return Ok(await _context.Owners.ToListAsync());
            }
        }
    }

