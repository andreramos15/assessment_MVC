﻿namespace Assessment_MVC.Models
{
    public class Claim
    {
            public int Id { get; set; }
            public string Description { get; set; } = string.Empty;
            public string Status { get; set; } = string.Empty;
            public DateTime Date { get; set; } 
            public int Vehicle_Id { get; set; }
        
    }
}
