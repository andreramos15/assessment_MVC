﻿namespace Assessment_MVC.Models
{
    public class Vehicle
    {
            public int Id { get; set; }
            public string Brand { get; set; } = string.Empty;
            public int Vin { get; set; }
            public string Color { get; set; } = string.Empty;
            public int Year { get; set; } 
            public int Owner_Id { get; set; }
            
        
    }
}
