﻿using Assessment_MVC.Controllers;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace Assessment_MVC.Data
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options) { }

        public DbSet<OwnersController> Owners { get; set; }
        public DbSet<ClaimsController> Claims { get; set; }
        public DbSet<VehiclesController> Vehicles { get; set; }
    }
}
